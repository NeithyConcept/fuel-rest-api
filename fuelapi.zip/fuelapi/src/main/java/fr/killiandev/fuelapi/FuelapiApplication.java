package fr.killiandev.fuelapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FuelapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FuelapiApplication.class, args);
	}

}
